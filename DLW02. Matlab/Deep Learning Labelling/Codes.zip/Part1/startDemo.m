% Copyright 2018 The MathWorks, Inc.

%% Clear everything
clc
clear
close all

%% Add folders to the path
addpath(genpath('Part1'),genpath('Part2'));
