% Copyright 2018 The MathWorks, Inc.

%% Clear everything
clc
clear
close all

%% Remove Folders from Path 
rmpath(genpath('Part1'),genpath('Part2'));
