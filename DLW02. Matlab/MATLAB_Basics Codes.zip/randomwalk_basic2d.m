% Random walk in 2D

close all;
clear all;

lamda = 6; % Mean free path
nsteps = 10;

x(1) = 0.0;
y(1) = 0.0;
z(1) = 0.0;


for i = 1 : nsteps
    
    theta = pi*rand();
    phi = 2*pi*rand(); % the angle is between 0 to 2pi; rand()returns random values between (0,1)
    
    r = -lamda*log(rand()); % take the step as the unit magnitude, later we can change that
    
    % for each of step we have found the value of r and value of theta
    % then we need to do the step size
    
    
    % the step size on the x and y axis, we can easily call them dx and dy
    dx = r*sin(theta)*cos(phi); 
    dy = r*sin(theta)*sin(phi);
    dz = r*cos(theta);
    % basically they are the changes in the respective axises
    
    x(i+1) = x(i) + dx;
    y(i+1) = y(i) + dy;
    z(i+1) = z(i) + dz;
    
end


% i want to plot the graph of a random walk, 'r' is the style of our graph
% in this example, i'd like my graph to be red and i want to join them
% so i use r-
plot(x, y, z, 'r-');
    
    
    