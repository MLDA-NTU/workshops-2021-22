% Isotropic distribution in 3D
 
close all;
clear all;
 
lamda = 6; % Mean free path
npoints = 5000;
 
for i = 1 : npoints
    
    r = 1;
    theta = pi*rand();
    phi = 2*pi*rand();        
    
    x(i) = r*sin(theta)*cos(phi); 
    y(i) = r*sin(theta)*sin(phi);
    z(i) = r*cos(theta);
    
    
end
 
plot3(x, y, z, 'r.');