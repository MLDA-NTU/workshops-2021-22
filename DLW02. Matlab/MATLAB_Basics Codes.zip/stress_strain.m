% Plot of data points extracted using GRABIT

load data
plot(DataAluminum(:,1), DataAluminum(:,2), 'b')
hold on
plot (DataSteel(:,1), DataSteel(:,2),'k')
title('Stress-strain curve of aluminum and steel')
xlabel('Strain')
ylabel('Stress')